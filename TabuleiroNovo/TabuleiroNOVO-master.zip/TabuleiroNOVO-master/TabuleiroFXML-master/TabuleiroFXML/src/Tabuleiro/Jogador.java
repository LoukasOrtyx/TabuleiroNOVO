// Decompiled by DJ v3.12.12.101 Copyright 2016 Atanas Neshkov  Date: 30/11/2017 19:29:26
// Home Page:  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Jogador.java
package Tabuleiro;

public class Jogador {

    public String getNome() {
        return Nome;
    }

    private void setNome(String nome) {
        Nome = nome;
    }

    public Jogador(String nome) {
        setNome(nome);
    }

    private String Nome;
}
